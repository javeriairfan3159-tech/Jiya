V380 Pro Guide — Store Assets
=============================

01-icon/
  ic_launcher_512.png     Play Store / App Store icon (required)
  ic_launcher_1024.png    High-res master

02-banner/
  banner_playstore_1024x500.png     Play Store feature graphic (required)
  feature_graphic_1024x500.png      Same file, extra copy
  banner_youtube_1920x1080.png      YouTube / ads
  banner_strip_1920x600.png         Website / Facebook header

03-screenshots/   (upload 01 to 06, this order)
  01-home-command-center.png
  02-smart-tools.png
  03-camera-pairing.png
  04-guides-overview.png
  05-storage-cloud.png
  06-firmware-recovery.png

04-video/
  v380-pro-guide-promo-16x9.mp4     Play Store / YouTube (~18s)
  v380-pro-guide-promo-9x16.mp4     Reels / Shorts / Status (~18s)

DESCRIPTIONS-EN-UR.md
  App name, short + long descriptions (English and Urdu)

Play Store video:
  Console MP4 seedha nahi leta. 16:9 video YouTube par unlisted
  upload karein, phir uska link Promo video field mein paste karein.
